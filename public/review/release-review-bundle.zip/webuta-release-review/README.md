# WebUtau Release Review Bundle

This bundle is an offline reviewer handoff for the WebUtau Korean V3 Synthetic community release.

It does not ask anyone to record a voice. Review only the generated synthetic V3 WAVs and the physical WAV/DAW import result.

## Public Links

- App: https://midagedev.github.io/webuta/
- Review hub: https://midagedev.github.io/webuta/review/
- Listening scorecard: https://midagedev.github.io/webuta/review/v3/
- WAV/DAW handoff: https://midagedev.github.io/webuta/review/wav-daw/

## Required Evidence

- `listening-scores.local.json`: generated only after real phrase-by-phrase listening.
- `handoff-report.local.json`: generated only after a real physical-device WAV/DAW import pass.

Use Evidence Preflight in the public review hub (https://midagedev.github.io/webuta/review/#evidence-preflight) to check both downloaded JSON files locally with no upload.

Keep both downloaded JSON files in Downloads, then run:

```sh
npm run release:evidence-status
npm run release:accept-evidence
npm run release:audit-utau
```

## Included Files

- `release-packet.json`: machine-readable release packet.
- `review/v3/index.html`: listening scorecard.
- `review/v3/audio/`: V3 and legacy V2 comparison WAVs.
- `review/wav-daw/index.html`: physical-device handoff report builder.
- `docs/WAV_DAW_QA.md`: physical-device checklist.
- `docs/LICENSE_BOUNDARIES.md`: bundled voicebank and third-party asset boundaries.
